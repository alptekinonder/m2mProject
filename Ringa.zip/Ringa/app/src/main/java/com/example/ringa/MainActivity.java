package com.example.ringa;
import android.os.AsyncTask;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.util.Log;
import android.view.View;

import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;

import java.io.BufferedReader;

import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;


public class MainActivity extends AppCompatActivity {
    EditText result;
    String id = "192.168.1.22";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.hiya);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = findViewById(R.id.fab);
        /*fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });*/
        result    =   (EditText)findViewById( R.id.Result );
        Button sendPost=(Button)findViewById(R.id.sendPost);
        Switch simpleSwitch = (Switch) findViewById(R.id.sesSwitch);
        sendPost.setOnClickListener(new Button.OnClickListener(){

            public void onClick(View v)
            {
                Log.d("myTag", "Something is wrong bro1");
                try{

                    // CALL GetText method to make post method call
                    EditText textToSend = (EditText)findViewById( R.id.postText );;
                    result.setText(new CallAPI().execute(textToSend.getText().toString(), "messageSend", id).get());

                    Log.d("myTag", "Something is wrong bro2");
                }
                catch(Exception ex)
                {
                    Log.d("myTag", "Something is wrong bro3");
                    Log.d("bura",ex.toString());
                }
            }
        });
        Button changePassword=(Button)findViewById(R.id.ChangePassword);

        changePassword.setOnClickListener(new Button.OnClickListener(){

            public void onClick(View v)
            {
                id = result.getText().toString();
            }
        });
        simpleSwitch.setOnClickListener(new Button.OnClickListener(){

            public void onClick(View v)
            {
                Log.d("myTag", "Something is wrong bro1");
                try{
                    boolean checked = simpleSwitch.isChecked();
                    if(checked)
                        result.setText(new CallAPI().execute((""+checked), "ses", id).get());
                    else
                        new CallAPI().execute((""+checked),  "ses", "1");
                    Log.d("myTag", "Something is wrong bro2");
                }
                catch(Exception ex)
                {
                    Log.d("myTag", "Something is wrong bro3");
                    Log.d("bura",ex.toString());
                }
            }
        });



    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}



class CallAPI extends AsyncTask<String, String, String> {
    public CallAPI(){
        //set context variables if required
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }
    String text;
    @Override
    protected String doInBackground(String... params) {
        //String urlString = "http://"+ params[2] +"80/"; // URL to call
        //String urlString = "http://192.168.0.22:80/"; // URL to call

        String urlString = "http://192.168.1.22:80/"; // URL to call
        urlString += params[1];
        OutputStream out = null;

        BufferedReader reader=null;

        try{
            String sendText = params[0];
            String data = URLEncoder.encode("Input", "UTF-8")
                    + "=" + URLEncoder.encode(sendText, "UTF-8");
            // Defined URL  where to send data
            URL url = new URL(urlString);

            // Send POST data request

            URLConnection conn = url.openConnection();
            conn.setDoOutput(true);
            OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
            wr.write( data );
            wr.flush();

            // Get the server response

            reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line = null;

            // Read Server Response
            while((line = reader.readLine()) != null)
            {
                // Append server response in string
                sb.append(line + "\n");
            }


            text = sb.toString();
        }
          catch(Exception ex)
        {

        }
          finally
        {
            try
            {

                reader.close();
            }

            catch(Exception ex) {}
        }

        // Show response on activity
        return text;
    }
}